import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Read the CSV file
data = pd.read_csv('t.csv')

# Select columns for clustering, for example, longitude and latitude
X = data[['longitude', 'latitude']]

# Define the number of clusters
n_clusters = 50

# Apply KMeans clustering
kmeans = KMeans(n_clusters=n_clusters)
kmeans.fit(X)

# Add the cluster results to the original data
data['cluster'] = kmeans.labels_

# Calculate cluster centers
centroids = kmeans.cluster_centers_

# Plotting the clusters and centroids
plt.figure(figsize=(10, 6))
plt.scatter(data['longitude'], data['latitude'], c=data['cluster'], cmap='viridis', marker='o', label='Stations')
plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='x', label='Centroids')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('KMeans Clustering of Service Stations with Centroids')
plt.legend()
plt.show()

# Optionally, save the cluster centers to a CSV file
centroids_df = pd.DataFrame(centroids, columns=['longitude', 'latitude'])
centroids_df.to_csv('cluster_centers.csv', index=False)  # Replace with your desired save path
