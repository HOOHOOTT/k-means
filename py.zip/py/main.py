import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# 读取 CSV 文件
data = pd.read_csv('t.csv')

# 选取用于聚类的列，例如经度和纬度
X = data[['longitude', 'latitude']]

# 定义聚类的数量
n_clusters = 50

# 应用 KMeans 聚类
kmeans = KMeans(n_clusters=n_clusters)
kmeans.fit(X)

# 将聚类结果添加到原始数据中
data['cluster'] = kmeans.labels_

# 可视化聚类结果
plt.scatter(data['longitude'], data['latitude'], c=data['cluster'])
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('KMeans Clustering of Service Stations')
plt.show()

# 打印聚类中心
centroids = kmeans.cluster_centers_
print("Cluster Centers: \n", centroids)
