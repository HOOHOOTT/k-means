import pandas as pd
import matplotlib.pyplot as plt

# Re-reading the original data and the centroids data
data = pd.read_csv('t.csv')
centroids_data = pd.read_csv('cluster_centers.csv')

# Plotting both the original data and the centroids
plt.figure(figsize=(10, 6))
plt.scatter(data['longitude'], data['latitude'], label='Original Data')
plt.scatter(centroids_data['longitude'], centroids_data['latitude'], c='red', marker='x', label='Centroids')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('KMeans Clustering of Service Stations with Centroids')
plt.legend()
plt.show()
